package com.sinisiro.helloSession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
