package com.sinisiro.helloSession.loginexample.domain.user;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Repository
public class UserRepository {

    private static Map<Long, User> store = new ConcurrentHashMap<>();
    private static long sequence = 0L;

    public User save(User member) {

        member.setId(++sequence);
        log.info("save: member={}", member);
        store.put(member.getId(), member);

        return member;
    }

    public User findById(Long id) {
        return store.get(id);
    }

    public Optional<User> findByLoginId(String loginId) {

        return this.findAll().stream()
                .filter(m -> m.getLoginId().equals(loginId))
                .findFirst();
    }

    public List<User> findAll() {
        return new ArrayList<>(store.values());
    }

    public void clearStore() {
        store.clear();
    }

    /**
     * 테스트용 데이터 추가
     */
    @PostConstruct
    public void init() {

        User member = new User();
        member.setLoginId("test");
        member.setPassword("test!");
        member.setName("테스터");

        save(member);
    }
}