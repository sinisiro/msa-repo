package com.sinisiro.helloSession.loginexample.domain.login;


import com.sinisiro.helloSession.loginexample.domain.user.User;
import com.sinisiro.helloSession.loginexample.domain.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class LoginService {

    private final UserRepository userRepository;

    /**
     * @return null이면 로그인 실패
     */
    public User login(String loginId, String password) {

        return userRepository.findByLoginId(loginId)
                .filter(m -> m.getPassword().equals(password))
                .orElse(null);
    }
}
