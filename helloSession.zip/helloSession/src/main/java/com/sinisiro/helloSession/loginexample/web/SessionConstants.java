package com.sinisiro.helloSession.loginexample.web;

public interface SessionConstants {

    String LOGIN_MEMBER = "loginMember";
}