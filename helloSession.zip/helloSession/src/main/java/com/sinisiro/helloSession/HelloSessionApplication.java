package com.sinisiro.helloSession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloSessionApplication.class, args);
	}

}
